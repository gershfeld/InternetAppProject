﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace secondHandPro.Models
{
    public class Connection
    {
        public User user;
    }
}